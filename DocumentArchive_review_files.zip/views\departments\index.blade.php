@extends('layouts.app')

@section('title', 'الإدارات')

@section('content')
    <div class="page-title">
        <h1>الإدارات</h1>
        @if(auth()->user()?->hasPermission('departments.manage'))
        <a href="{{ route('departments.create') }}" class="btn btn-primary">+ إضافة إدارة</a>
        @endif
    </div>

    <div class="card">
        <table>
            <thead>
            <tr>
                <th>الاسم
</th>
                <th>الكود</th>
                <th>الوصف</th>
                <th>الحالة</th>
                <th>عدد الم
ستندات</th>
                <th>إجراءات</th>
            </tr>
            </thead>
            <tbody>
            @forelse($departments as $department)
                <tr>
                    <td><strong>{{ $department->name }}</strong></td>
                    <td>{{ $department->code ?? '-' }}</td>
                    <td>{{ $department->description ?? '-' }}</td>
                    <td>
                        @if($department->is_active)
                            <span class="badge">نشطة</span>
                        @else
                            <span class="badge">م
عطلة</span>
                        @endif
                    </td>
                    <td>{{ $department->documents_count }}</td>
                    <td>
                        <div class="actions">
                            @if(auth()->user()?->hasPermission('departments.manage'))
                            <a href="{{ route('departments.edit', $department) }}" class="btn btn-primary">تعديل</a>
                            @endif
                            <form method="POST" action="{{ route('departments.destroy', $department) }}" data-confirm="هل أنت م
تأكد م
ن حذف أو تعطيل هذه الإدارة؟">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">حذف</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6">لا توجد إدارات حتى الآن.</td></tr>
            @endforelse
            </tbody>
        </table>
        <div class="pagination">{{ $departments->links() }}</div>
    </div>
@endsection
