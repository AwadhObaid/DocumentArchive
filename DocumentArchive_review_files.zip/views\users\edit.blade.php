@extends('layouts.app')

@section('title', 'تعديل م
ستخدم
')
@section('page_title', 'تعديل م
ستخدم
')
@section('page_subtitle', 'تعديل بيانات الحساب والدور والصلاحيات')

@section('content')
    <div class="page-title">
        <h2>تعديل م
ستخدم
</h2>
        @if(auth()->user()?->hasPermission('users.manage'))
        <a href="{{ route('users.index') }}" class="btn btn-secondary">رجوع</a>
        @endif
    </div>

    <div class="card">
        <form method="POST" action="{{ route('users.update', $user) }}">
            @csrf
            @method('PUT')

            <div class="form-grid">
                <div class="form-group">
                    <label>الاسم
</label>
                    <input type="text" name="name" value="{{ old('name', $user->name) }}" required>
                </div>

                <div class="form-group">
                    <label>اسم
 الم
ستخدم
</label>
                    <input type="text" name="username" value="{{ old('username', $user->username) }}" required>
                </div>

                <div class="form-group">
                    <label>البريد الإلكتروني</label>
                    <input type="email" name="email" value="{{ old('email', $user->email) }}">
                </div>

                <div class="form-group">
                    <label>الهاتف</label>
                    <input type="text" name="phone" value="{{ old('phone', $user->phone) }}">
                </div>

                <div class="form-group">
                    <label>الدور</label>
                    <select name="role" required>
                        <option value="user" @selected(old('role', $user->role) === 'user')>م
ستخدم
</option>
                        <option value="viewer" @selected(old('role', $user->role) === 'viewer')>م
شاهد فقط</option>
                        <option value="admin" @selected(old('role', $user->role) === 'admin')>م
دير النظام
</option>
                    </select>
                    <small style="display:block;margin-top:6px;color:#64748b;">م
دير النظام
 يم
لك كل الصلاحيات تلقائياً.</small>
                </div>

                <div class="form-group">
                    <label>الحالة</label>
                    <label class="checkbox-line">
                        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $user->is_active))>
                        م
ستخدم
 نشط
                    </label>
                </div>
            </div>

            @php
                $selectedPermissions = old('permissions', $defaultPermissions ?? []);
                if (!is_array($selectedPermissions)) {
                    $selectedPermissions = [];
                }
            @endphp

            <div class="permissions-panel">
                <div class="permissions-header">
                    <div>
                        <h3>الصلاحيات التفصيلية</h3>
                        <p>تحديد الصلاحيات الخاصة بهذا الم
ستخدم
. عند اختيار م
دير النظام
 يتم
 تجاهل هذه القائم
ة ويُم
نح كل الصلاحيات.</p>
                    </div>
                    <button type="button" class="btn btn-secondary" onclick="toggleAllPermissions(true)">تحديد الكل</button>
                    <button type="button" class="btn btn-secondary" onclick="toggleAllPermissions(false)">إلغاء الكل</button>
                </div>

                <div class="permissions-grid">
                    @foreach ($permissionGroups as $group)
                        <div class="permission-group">
                            <strong>{{ $group['label'] }}</strong>
                            @foreach ($group['permissions'] as $permissionKey => $permissionLabel)
                                <label class="permission-item">
                                    <input type="checkbox" name="permissions[]" value="{{ $permissionKey }}" @checked(in_array('*', $selectedPermissions, true) || in_array($permissionKey, $selectedPermissions, true))>
                                    <span>{{ $permissionLabel }}</span>
                                </label>
                            @endforeach
                        </div>
                    @endforeach
                </div>
            </div>

            <div style="margin-top:20px;">
                <button type="submit" class="btn btn-success">حفظ التعديلات</button>
            </div>
        </form>
    </div>

    <style>
        .permissions-panel { margin-top: 24px; border: 1px solid #e5e7eb; border-radius: 16px; padding: 18px; background: #f8fafc; }
        .permissions-header { display: flex; align-items: center; gap: 10px; justify-content: space-between; flex-wrap: wrap; margin-bottom: 16px; }
        .permissions-header h3 { margin: 0 0 4px; font-size: 18px; }
        .permissions-header p { margin: 0; color: #64748b; }
        .permissions-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 14px; }
        .permission-group { background: #fff; border: 1px solid #e5e7eb; border-radius: 14px; padding: 14px; }
        .permission-group strong { display: block; margin-bottom: 10px; color: #0f172a; }
        .permission-item { display: flex; gap: 8px; align-items: center; margin: 8px 0; color: #334155; }
        .permission-item input { width: auto; }
    </style>

    <script>
        function toggleAllPermissions(checked) {
            document.querySelectorAll('input[name="permissions[]"]').forEach((checkbox) => checkbox.checked = checked);
        }
    </script>
@endsection
