﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$AppName = 'DocumentArchive File Bridge'
$ConfigRoot = Join-Path $env:LOCALAPPDATA 'DocumentArchiveFileBridge'
$ConfigPath = Join-Path $ConfigRoot 'config.json'


function Normalize-ApprovedRoot {
    param([Parameter(Mandatory = $true)][string]$Path)

    $full = [System.IO.Path]::GetFullPath($Path)
    if ($full -match '^[A-Za-z]:\$') {
        return $full
    }

    return $full.TrimEnd('\')
}

function Load-Roots {
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { return @() }

    try {
        $config = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        return @($config.roots) |
            Where-Object { $_ } |
            ForEach-Object { Normalize-ApprovedRoot -Path ([string]$_) } |
            Sort-Object -Unique
    }
    catch {
        return @()
    }
}

function Save-Roots {
    param([string[]]$Roots)

    New-Item -ItemType Directory -Path $ConfigRoot -Force | Out-Null
    $payload = [ordered]@{
        version = '94.2'
        roots = @($Roots | Sort-Object -Unique)
        updated_at = (Get-Date).ToString('o')
    }
    $json = $payload | ConvertTo-Json -Depth 4
    [System.IO.File]::WriteAllText($ConfigPath, $json, [System.Text.UTF8Encoding]::new($false))
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'إعداد مجلدات DocumentArchive File Bridge'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(760, 480)
$form.MinimumSize = New-Object System.Drawing.Size(650, 420)
$form.RightToLeft = 'Yes'
$form.RightToLeftLayout = $true
$form.Font = New-Object System.Drawing.Font('Tahoma', 9)

$title = New-Object System.Windows.Forms.Label
$title.Text = 'المجلدات المحلية المسموح البحث داخلها'
$title.Font = New-Object System.Drawing.Font('Tahoma', 14, [System.Drawing.FontStyle]::Bold)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(20, 18)
$form.Controls.Add($title)

$note = New-Object System.Windows.Forms.Label
$note.Text = 'لا يستطيع File Bridge قراءة أو رفع ملف خارج هذه القائمة. أضف مجلد الأرشيف المحلي فقط بدلاً من اعتماد القرص كاملاً متى أمكن.'
$note.AutoSize = $false
$note.Location = New-Object System.Drawing.Point(20, 55)
$note.Size = New-Object System.Drawing.Size(710, 45)
$form.Controls.Add($note)

$list = New-Object System.Windows.Forms.ListBox
$list.Location = New-Object System.Drawing.Point(20, 108)
$list.Size = New-Object System.Drawing.Size(710, 245)
$list.Anchor = 'Top,Bottom,Left,Right'
$form.Controls.Add($list)

$addButton = New-Object System.Windows.Forms.Button
$addButton.Text = 'إضافة مجلد'
$addButton.Location = New-Object System.Drawing.Point(20, 370)
$addButton.Size = New-Object System.Drawing.Size(115, 38)
$addButton.Anchor = 'Bottom,Left'
$form.Controls.Add($addButton)

$removeButton = New-Object System.Windows.Forms.Button
$removeButton.Text = 'إزالة المحدد'
$removeButton.Location = New-Object System.Drawing.Point(145, 370)
$removeButton.Size = New-Object System.Drawing.Size(115, 38)
$removeButton.Anchor = 'Bottom,Left'
$form.Controls.Add($removeButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Text = 'إلغاء'
$cancelButton.Location = New-Object System.Drawing.Point(500, 370)
$cancelButton.Size = New-Object System.Drawing.Size(105, 38)
$cancelButton.Anchor = 'Bottom,Right'
$form.Controls.Add($cancelButton)

$saveButton = New-Object System.Windows.Forms.Button
$saveButton.Text = 'حفظ'
$saveButton.Location = New-Object System.Drawing.Point(615, 370)
$saveButton.Size = New-Object System.Drawing.Size(115, 38)
$saveButton.Anchor = 'Bottom,Right'
$saveButton.BackColor = [System.Drawing.Color]::FromArgb(15, 118, 110)
$saveButton.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($saveButton)

foreach ($root in (Load-Roots)) { $list.Items.Add($root) | Out-Null }

$addButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'اختر مجلد الأرشيف المحلي المسموح البحث داخله'
    $dialog.ShowNewFolderButton = $false

    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $selected = Normalize-ApprovedRoot -Path $dialog.SelectedPath
        if (-not $list.Items.Contains($selected)) {
            $list.Items.Add($selected) | Out-Null
        }
    }
})

$removeButton.Add_Click({
    while ($list.SelectedIndices.Count -gt 0) {
        $list.Items.RemoveAt($list.SelectedIndices[0])
    }
})

$cancelButton.Add_Click({ $form.Close() })
$saveButton.Add_Click({
    $roots = @($list.Items | ForEach-Object { [string]$_ })
    Save-Roots -Roots $roots
    [System.Windows.Forms.MessageBox]::Show(
        'تم حفظ المجلدات المعتمدة بنجاح.',
        $AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
    $form.Close()
})

[System.Windows.Forms.Application]::Run($form)
