﻿param(
    [Parameter(Position = 0)]
    [string]$Uri
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Web
Add-Type -AssemblyName System.Net.Http

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

$AppName = 'DocumentArchive File Bridge'
$ConfigRoot = Join-Path $env:LOCALAPPDATA 'DocumentArchiveFileBridge'
$ConfigPath = Join-Path $ConfigRoot 'config.json'
$ConfigureScript = Join-Path $PSScriptRoot 'Configure-DocumentArchiveFileBridge.ps1'
$script:AllowUntrustedForSession = $false
$script:HttpClient = $null
$script:SearchResults = New-Object 'System.Collections.Generic.List[object]'
$script:RequestMetadata = $null
$script:ClientToken = ''

function Show-Error {
    param([string]$Message)

    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        $AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Show-Info {
    param([string]$Message)

    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        $AppName,
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function New-HttpClient {
    if ($script:HttpClient) {
        try { $script:HttpClient.Dispose() } catch {}
    }

    if ($script:AllowUntrustedForSession) {
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
    }
    else {
        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = $null
    }

    $handler = [System.Net.Http.HttpClientHandler]::new()
    if ($script:AllowUntrustedForSession -and $handler.PSObject.Properties.Name -contains 'ServerCertificateCustomValidationCallback') {
        try {
            $handler.ServerCertificateCustomValidationCallback = { param($message, $certificate, $chain, $errors) return $true }
        }
        catch {
            # ServicePointManager callback above remains the compatibility fallback for Windows PowerShell 5.1.
        }
    }
    $client = [System.Net.Http.HttpClient]::new($handler)
    $client.Timeout = [TimeSpan]::FromMinutes(5)
    $client.DefaultRequestHeaders.UserAgent.ParseAdd('DocumentArchive-FileBridge/94.2')
    if (-not [string]::IsNullOrWhiteSpace($script:ClientToken)) {
        $client.DefaultRequestHeaders.Add('X-File-Bridge-Token', $script:ClientToken)
    }
    $script:HttpClient = $client

    return $client
}

function Invoke-JsonGet {
    param([Parameter(Mandatory = $true)][string]$Url)

    $client = New-HttpClient

    try {
        $response = $client.GetAsync($Url).GetAwaiter().GetResult()
        $body = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()

        if (-not $response.IsSuccessStatusCode) {
            try {
                $json = $body | ConvertFrom-Json
                throw [System.Exception]::new([string]$json.message)
            }
            catch {
                if ($_.Exception.Message -and $_.Exception.Message -ne $body) { throw }
                throw [System.Exception]::new("تعذر الاتصال بالسيرفر. HTTP $([int]$response.StatusCode)")
            }
        }

        return $body | ConvertFrom-Json
    }
    catch {
        if (-not $script:AllowUntrustedForSession -and $_.Exception.Message -match 'SSL|certificate|trust|authentication') {
            $answer = [System.Windows.Forms.MessageBox]::Show(
                "تعذر التحقق من شهادة HTTPS الخاصة بالسيرفر.`r`n`r`nهل تريد السماح بهذه الشهادة لهذه الجلسة فقط؟",
                $AppName,
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )

            if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
                $script:AllowUntrustedForSession = $true
                return Invoke-JsonGet -Url $Url
            }
        }

        throw
    }
}

function Invoke-JsonPostFile {
    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string]$OriginalName
    )

    $client = New-HttpClient
    $multipart = [System.Net.Http.MultipartFormDataContent]::new()
    $stream = $null

    try {
        $stream = [System.IO.File]::Open(
            $FilePath,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::Read
        )

        $fileContent = [System.Net.Http.StreamContent]::new($stream)
        $fileContent.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::new('application/octet-stream')
        $multipart.Add($fileContent, 'file', 'bridge-upload.bin')
        $multipart.Add([System.Net.Http.StringContent]::new($OriginalName, [System.Text.Encoding]::UTF8), 'original_name')
        $multipart.Add([System.Net.Http.StringContent]::new([Environment]::UserName, [System.Text.Encoding]::UTF8), 'client_name')
        $multipart.Add([System.Net.Http.StringContent]::new([Environment]::MachineName, [System.Text.Encoding]::UTF8), 'client_machine')

        $response = $client.PostAsync($Url, $multipart).GetAwaiter().GetResult()
        $body = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()

        if (-not $response.IsSuccessStatusCode) {
            try {
                $json = $body | ConvertFrom-Json
                $message = [string]$json.message
                if ($json.errors) {
                    $messages = New-Object 'System.Collections.Generic.List[string]'
                    foreach ($property in $json.errors.PSObject.Properties) {
                        foreach ($item in @($property.Value)) {
                            $messages.Add([string]$item)
                        }
                    }
                    if ($messages.Count -gt 0) {
                        $message = $messages -join "`r`n"
                    }
                }
                throw [System.Exception]::new($message)
            }
            catch {
                if ($_.Exception.Message -and $_.Exception.Message -ne $body) { throw }
                throw [System.Exception]::new("فشل رفع الملف. HTTP $([int]$response.StatusCode)")
            }
        }

        return $body | ConvertFrom-Json
    }
    catch {
        if (-not $script:AllowUntrustedForSession -and $_.Exception.Message -match 'SSL|certificate|trust|authentication') {
            $answer = [System.Windows.Forms.MessageBox]::Show(
                "تعذر التحقق من شهادة HTTPS الخاصة بالسيرفر.`r`n`r`nهل تريد السماح بهذه الشهادة لهذه الجلسة فقط؟",
                $AppName,
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )

            if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
                $script:AllowUntrustedForSession = $true
                return Invoke-JsonPostFile -Url $Url -FilePath $FilePath -OriginalName $OriginalName
            }
        }

        throw
    }
    finally {
        if ($multipart) { $multipart.Dispose() }
        if ($stream) { $stream.Dispose() }
    }
}


function Normalize-ApprovedRoot {
    param([Parameter(Mandatory = $true)][string]$Path)

    $full = [System.IO.Path]::GetFullPath($Path)
    if ($full -match '^[A-Za-z]:\$') {
        return $full
    }

    return $full.TrimEnd('\')
}

function Get-ApprovedRoots {
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
        return @()
    }

    try {
        $config = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $roots = @($config.roots) |
            Where-Object { $_ -and (Test-Path -LiteralPath ([string]$_) -PathType Container) } |
            ForEach-Object { Normalize-ApprovedRoot -Path ([string]$_) } |
            Sort-Object -Unique

        return @($roots)
    }
    catch {
        return @()
    }
}

function Test-PathUnderApprovedRoot {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string[]]$Roots
    )

    $fullPath = [System.IO.Path]::GetFullPath($Path)

    foreach ($root in $Roots) {
        $fullRoot = Normalize-ApprovedRoot -Path $root
        if ($fullPath.Equals($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            return $true
        }

        $prefix = if ($fullRoot.EndsWith('\')) { $fullRoot } else { $fullRoot + '\' }
        if ($fullPath.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            return $true
        }
    }

    return $false
}

function Format-Bytes {
    param([long]$Bytes)

    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N2} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N2} KB' -f ($Bytes / 1KB)) }
    return "$Bytes Bytes"
}

function Get-ProtocolRequest {
    param([string]$ProtocolUri)

    if ([string]::IsNullOrWhiteSpace($ProtocolUri)) {
        return $null
    }

    try {
        $parsed = [Uri]$ProtocolUri
        if ($parsed.Scheme -ne 'documentarchive') {
            throw 'بروتوكول الاستدعاء غير صحيح.'
        }

        $query = [System.Web.HttpUtility]::ParseQueryString($parsed.Query)
        $requestUrl = [string]$query['request']
        $token = [string]$query['token']

        if ([string]::IsNullOrWhiteSpace($requestUrl) -or [string]::IsNullOrWhiteSpace($token)) {
            throw 'رابط الطلب أو رمز File Bridge غير موجود.'
        }

        $requestUri = [Uri]$requestUrl
        if ($requestUri.Scheme -ne 'https' -and $requestUri.Scheme -ne 'http') {
            throw 'رابط السيرفر غير مسموح.'
        }

        return [PSCustomObject]@{
            RequestUrl = $requestUri.AbsoluteUri
            Token = $token
        }
    }
    catch {
        throw [System.Exception]::new('تعذر قراءة طلب File Bridge: ' + $_.Exception.Message)
    }
}

function Invoke-Configuration {
    if (-not (Test-Path -LiteralPath $ConfigureScript -PathType Leaf)) {
        Show-Error 'ملف إعداد المجلدات غير موجود.'
        return
    }

    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $ConfigureScript
}

try {
    $protocolRequest = Get-ProtocolRequest -ProtocolUri $Uri
    if (-not $protocolRequest) {
        Invoke-Configuration
        exit 0
    }

    $script:ClientToken = [string]$protocolRequest.Token
    $script:RequestMetadata = Invoke-JsonGet -Url ([string]$protocolRequest.RequestUrl)
    if (-not $script:RequestMetadata.ok) {
        throw [System.Exception]::new([string]$script:RequestMetadata.message)
    }
}
catch {
    Show-Error $_.Exception.Message
    exit 1
}

$form = New-Object System.Windows.Forms.Form
$form.Text = $AppName
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(1040, 700)
$form.MinimumSize = New-Object System.Drawing.Size(900, 580)
$form.RightToLeft = 'Yes'
$form.RightToLeftLayout = $true
$form.Font = New-Object System.Drawing.Font('Tahoma', 9)
$form.TopMost = $true

$header = New-Object System.Windows.Forms.Label
$header.Text = 'البحث في ملفات الجهاز المحلي'
$header.Font = New-Object System.Drawing.Font('Tahoma', 15, [System.Drawing.FontStyle]::Bold)
$header.AutoSize = $true
$header.Location = New-Object System.Drawing.Point(25, 18)
$form.Controls.Add($header)

$expiryLabel = New-Object System.Windows.Forms.Label
$expiryLabel.Text = "ينتهي الطلب: $($script:RequestMetadata.expires_at)"
$expiryLabel.AutoSize = $true
$expiryLabel.Location = New-Object System.Drawing.Point(27, 55)
$form.Controls.Add($expiryLabel)

$queryLabel = New-Object System.Windows.Forms.Label
$queryLabel.Text = 'رقم الكتاب أو اسم الملف'
$queryLabel.AutoSize = $true
$queryLabel.Location = New-Object System.Drawing.Point(25, 91)
$form.Controls.Add($queryLabel)

$queryBox = New-Object System.Windows.Forms.TextBox
$queryBox.Location = New-Object System.Drawing.Point(25, 113)
$queryBox.Size = New-Object System.Drawing.Size(360, 28)
$queryBox.Text = [string]$script:RequestMetadata.query
$form.Controls.Add($queryBox)

$rootLabel = New-Object System.Windows.Forms.Label
$rootLabel.Text = 'المجلد المعتمد'
$rootLabel.AutoSize = $true
$rootLabel.Location = New-Object System.Drawing.Point(405, 91)
$form.Controls.Add($rootLabel)

$rootCombo = New-Object System.Windows.Forms.ComboBox
$rootCombo.DropDownStyle = 'DropDownList'
$rootCombo.Location = New-Object System.Drawing.Point(405, 113)
$rootCombo.Size = New-Object System.Drawing.Size(360, 28)
$form.Controls.Add($rootCombo)

$recursiveCheck = New-Object System.Windows.Forms.CheckBox
$recursiveCheck.Text = 'البحث داخل المجلدات الفرعية'
$recursiveCheck.Checked = $true
$recursiveCheck.AutoSize = $true
$recursiveCheck.Location = New-Object System.Drawing.Point(25, 154)
$form.Controls.Add($recursiveCheck)

$configureButton = New-Object System.Windows.Forms.Button
$configureButton.Text = 'إدارة المجلدات'
$configureButton.Location = New-Object System.Drawing.Point(785, 108)
$configureButton.Size = New-Object System.Drawing.Size(125, 36)
$form.Controls.Add($configureButton)

$searchButton = New-Object System.Windows.Forms.Button
$searchButton.Text = 'بحث'
$searchButton.Location = New-Object System.Drawing.Point(925, 108)
$searchButton.Size = New-Object System.Drawing.Size(85, 36)
$searchButton.BackColor = [System.Drawing.Color]::FromArgb(15, 118, 110)
$searchButton.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($searchButton)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = 'جاهز للبحث.'
$statusLabel.AutoSize = $false
$statusLabel.Location = New-Object System.Drawing.Point(25, 184)
$statusLabel.Size = New-Object System.Drawing.Size(985, 30)
$form.Controls.Add($statusLabel)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(25, 218)
$grid.Size = New-Object System.Drawing.Size(985, 355)
$grid.Anchor = 'Top,Bottom,Left,Right'
$grid.ReadOnly = $true
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.MultiSelect = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.AutoGenerateColumns = $false
$grid.RowHeadersVisible = $false

$nameColumn = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$nameColumn.HeaderText = 'اسم الملف'
$nameColumn.Width = 330
$grid.Columns.Add($nameColumn) | Out-Null

$sizeColumn = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$sizeColumn.HeaderText = 'الحجم'
$sizeColumn.Width = 100
$grid.Columns.Add($sizeColumn) | Out-Null

$dateColumn = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$dateColumn.HeaderText = 'آخر تعديل'
$dateColumn.Width = 145
$grid.Columns.Add($dateColumn) | Out-Null

$pathColumn = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$pathColumn.HeaderText = 'المسار'
$pathColumn.AutoSizeMode = 'Fill'
$grid.Columns.Add($pathColumn) | Out-Null
$form.Controls.Add($grid)

$openButton = New-Object System.Windows.Forms.Button
$openButton.Text = 'فتح الملف'
$openButton.Location = New-Object System.Drawing.Point(25, 592)
$openButton.Size = New-Object System.Drawing.Size(120, 38)
$openButton.Anchor = 'Bottom,Left'
$form.Controls.Add($openButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Text = 'إلغاء'
$cancelButton.Location = New-Object System.Drawing.Point(755, 592)
$cancelButton.Size = New-Object System.Drawing.Size(110, 38)
$cancelButton.Anchor = 'Bottom,Right'
$form.Controls.Add($cancelButton)

$uploadButton = New-Object System.Windows.Forms.Button
$uploadButton.Text = 'اختيار ورفع الملف'
$uploadButton.Location = New-Object System.Drawing.Point(880, 592)
$uploadButton.Size = New-Object System.Drawing.Size(130, 38)
$uploadButton.Anchor = 'Bottom,Right'
$uploadButton.BackColor = [System.Drawing.Color]::FromArgb(22, 163, 74)
$uploadButton.ForeColor = [System.Drawing.Color]::White
$form.Controls.Add($uploadButton)

function Refresh-Roots {
    $rootCombo.Items.Clear()
    $roots = @(Get-ApprovedRoots)

    if ($roots.Count -gt 1) {
        $rootCombo.Items.Add('جميع المجلدات المعتمدة') | Out-Null
    }

    foreach ($root in $roots) {
        $rootCombo.Items.Add($root) | Out-Null
    }

    if ($rootCombo.Items.Count -gt 0) {
        $rootCombo.SelectedIndex = 0
    }
    else {
        $statusLabel.Text = 'لا توجد مجلدات معتمدة. اضغط «إدارة المجلدات» لإضافتها.'
    }
}

function Get-SelectedRoots {
    $roots = @(Get-ApprovedRoots)
    if ($rootCombo.SelectedItem -and [string]$rootCombo.SelectedItem -ne 'جميع المجلدات المعتمدة') {
        return @([string]$rootCombo.SelectedItem)
    }

    return $roots
}

function Render-Results {
    $grid.Rows.Clear()

    foreach ($item in $script:SearchResults) {
        $index = $grid.Rows.Add()
        $row = $grid.Rows[$index]
        $row.Cells[0].Value = $item.Name
        $row.Cells[1].Value = Format-Bytes -Bytes $item.Size
        $row.Cells[2].Value = $item.Modified.ToString('yyyy-MM-dd HH:mm')
        $row.Cells[3].Value = $item.FullPath
        $row.Tag = $item
    }
}

function Invoke-LocalSearch {
    $query = $queryBox.Text.Trim()
    if ($query.Length -lt 2) {
        Show-Error 'اكتب حرفين أو رقمين على الأقل للبحث.'
        return
    }

    $roots = @(Get-SelectedRoots)
    if ($roots.Count -eq 0) {
        Show-Error 'لا توجد مجلدات معتمدة للبحث.'
        return
    }

    $allowedExtensions = @($script:RequestMetadata.allowed_extensions | ForEach-Object { ([string]$_).ToLowerInvariant() })
    $maxBytes = [long]$script:RequestMetadata.max_file_bytes
    $deadline = [DateTime]::UtcNow.AddSeconds(25)
    $script:SearchResults.Clear()
    $searchButton.Enabled = $false
    $statusLabel.Text = 'جارٍ البحث...'
    [System.Windows.Forms.Application]::DoEvents()

    try {
        foreach ($root in $roots) {
            if ([DateTime]::UtcNow -ge $deadline -or $script:SearchResults.Count -ge 200) { break }

            $parameters = @{
                LiteralPath = $root
                File = $true
                ErrorAction = 'SilentlyContinue'
            }
            if ($recursiveCheck.Checked) { $parameters.Recurse = $true }

            foreach ($file in (Get-ChildItem @parameters)) {
                if ([DateTime]::UtcNow -ge $deadline -or $script:SearchResults.Count -ge 200) { break }
                if (($file.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { continue }

                $extension = $file.Extension.TrimStart('.').ToLowerInvariant()
                if ($allowedExtensions -notcontains $extension) { continue }
                if ([long]$file.Length -le 0 -or [long]$file.Length -gt $maxBytes) { continue }

                $searchText = $file.Name + ' ' + $file.FullName
                if ($searchText.IndexOf($query, [System.StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
                if (-not (Test-PathUnderApprovedRoot -Path $file.FullName -Roots $roots)) { continue }

                $script:SearchResults.Add([PSCustomObject]@{
                    Name = $file.Name
                    FullPath = $file.FullName
                    Size = [long]$file.Length
                    Modified = $file.LastWriteTime
                })
            }
        }

        $ordered = @($script:SearchResults | Sort-Object -Property @{ Expression = 'Modified'; Descending = $true }, Name)
        $script:SearchResults.Clear()
        foreach ($item in $ordered) { $script:SearchResults.Add($item) }

        Render-Results
        $timedOut = [DateTime]::UtcNow -ge $deadline
        $statusLabel.Text = "تم العثور على $($script:SearchResults.Count) ملف" + $(if ($timedOut) { ' — انتهت مهلة البحث.' } else { '.' })
    }
    catch {
        Show-Error ('تعذر البحث: ' + $_.Exception.Message)
        $statusLabel.Text = 'فشل البحث.'
    }
    finally {
        $searchButton.Enabled = $true
    }
}

$configureButton.Add_Click({
    Invoke-Configuration
    Refresh-Roots
})

$searchButton.Add_Click({ Invoke-LocalSearch })
$queryBox.Add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $_.SuppressKeyPress = $true
        Invoke-LocalSearch
    }
})

$openButton.Add_Click({
    if ($grid.SelectedRows.Count -eq 0) {
        Show-Error 'اختر ملفاً أولاً.'
        return
    }

    $item = $grid.SelectedRows[0].Tag
    if ($item -and (Test-Path -LiteralPath $item.FullPath -PathType Leaf)) {
        Start-Process -FilePath $item.FullPath
    }
})

$cancelButton.Add_Click({ $form.Close() })

$uploadButton.Add_Click({
    if ($grid.SelectedRows.Count -eq 0) {
        Show-Error 'اختر ملفاً أولاً.'
        return
    }

    $item = $grid.SelectedRows[0].Tag
    $approvedRoots = @(Get-ApprovedRoots)

    if (-not $item -or -not (Test-Path -LiteralPath $item.FullPath -PathType Leaf)) {
        Show-Error 'الملف المختار لم يعد موجوداً.'
        return
    }

    if (-not (Test-PathUnderApprovedRoot -Path $item.FullPath -Roots $approvedRoots)) {
        Show-Error 'الملف خارج المجلدات المحلية المعتمدة.'
        return
    }

    $currentInfo = Get-Item -LiteralPath $item.FullPath
    if ([long]$currentInfo.Length -gt [long]$script:RequestMetadata.max_file_bytes) {
        Show-Error "حجم الملف يتجاوز الحد المسموح وهو $($script:RequestMetadata.max_file_mb) MB."
        return
    }

    $uploadButton.Enabled = $false
    $searchButton.Enabled = $false
    $statusLabel.Text = 'جارٍ رفع الملف إلى DocumentArchive...'
    [System.Windows.Forms.Application]::DoEvents()

    try {
        $response = Invoke-JsonPostFile `
            -Url ([string]$script:RequestMetadata.upload_url) `
            -FilePath $item.FullPath `
            -OriginalName $item.Name

        if (-not $response.ok) {
            throw [System.Exception]::new([string]$response.message)
        }

        Show-Info 'تم رفع الملف بنجاح. ارجع إلى صفحة الكتاب؛ سيظهر الاختيار تلقائياً.'
        $form.Close()
    }
    catch {
        Show-Error ('فشل رفع الملف: ' + $_.Exception.Message)
        $statusLabel.Text = 'فشل رفع الملف.'
    }
    finally {
        $uploadButton.Enabled = $true
        $searchButton.Enabled = $true
    }
})

Refresh-Roots
$form.Add_Shown({
    $form.Activate()
    if ($rootCombo.Items.Count -eq 0) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            'لا توجد مجلدات معتمدة. هل تريد إضافتها الآن؟',
            $AppName,
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
            Invoke-Configuration
            Refresh-Roots
        }
    }
    elseif ($queryBox.Text.Trim().Length -ge 2) {
        Invoke-LocalSearch
    }
})

[System.Windows.Forms.Application]::Run($form)
