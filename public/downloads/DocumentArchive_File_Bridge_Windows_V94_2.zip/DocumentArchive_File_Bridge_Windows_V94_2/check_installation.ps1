﻿$ErrorActionPreference = 'Stop'

$InstallRoot = Join-Path $env:LOCALAPPDATA 'DocumentArchiveFileBridge'
$ProtocolRoot = 'HKCU:\Software\Classes\documentarchive\shell\open\command'
$Failed = $false

function Test-BridgeItem {
    param([bool]$Condition, [string]$Message)
    if ($Condition) {
        Write-Host "[ OK ] $Message" -ForegroundColor Green
    }
    else {
        Write-Host "[FAIL] $Message" -ForegroundColor Red
        $script:Failed = $true
    }
}

Test-BridgeItem (Test-Path -LiteralPath (Join-Path $InstallRoot 'DocumentArchiveFileBridge.ps1')) 'Bridge script installed'
Test-BridgeItem (Test-Path -LiteralPath (Join-Path $InstallRoot 'Configure-DocumentArchiveFileBridge.ps1')) 'Configuration script installed'
Test-BridgeItem (Test-Path -LiteralPath $ProtocolRoot) 'documentarchive protocol registered'

if (Test-Path -LiteralPath $ProtocolRoot) {
    $command = (Get-Item -LiteralPath $ProtocolRoot).GetValue('')
    Test-BridgeItem ($command -match 'DocumentArchiveFileBridge\.ps1') 'Protocol points to the bridge script'
}

if ($Failed) { exit 1 }
Write-Host ''
Write-Host 'DocumentArchive File Bridge V94.2 verification PASSED.' -ForegroundColor Green
