﻿param(
    [switch]$SkipConfiguration
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$AppName = 'DocumentArchive File Bridge'
$InstallRoot = Join-Path $env:LOCALAPPDATA 'DocumentArchiveFileBridge'
$StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\DocumentArchive File Bridge'
$PowerShellExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"

Write-Host ''
Write-Host 'Installing DocumentArchive File Bridge V94.2...' -ForegroundColor Cyan

New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
New-Item -ItemType Directory -Path $StartMenu -Force | Out-Null

$Files = @(
    'DocumentArchiveFileBridge.ps1',
    'Configure-DocumentArchiveFileBridge.ps1',
    'uninstall.ps1',
    'README_AR.txt'
)

foreach ($File in $Files) {
    $Source = Join-Path $PSScriptRoot $File
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) {
        throw "Missing package file: $File"
    }
    Copy-Item -LiteralPath $Source -Destination (Join-Path $InstallRoot $File) -Force
}

$ProtocolRoot = 'HKCU:\Software\Classes\documentarchive'
New-Item -Path $ProtocolRoot -Force | Out-Null
Set-Item -Path $ProtocolRoot -Value 'URL:DocumentArchive File Bridge Protocol'
Set-ItemProperty -Path $ProtocolRoot -Name 'URL Protocol' -Value ''
New-Item -Path "$ProtocolRoot\DefaultIcon" -Force | Out-Null
Set-Item -Path "$ProtocolRoot\DefaultIcon" -Value "$PowerShellExe,0"
New-Item -Path "$ProtocolRoot\shell\open\command" -Force | Out-Null

$BridgeScript = Join-Path $InstallRoot 'DocumentArchiveFileBridge.ps1'
$Command = '"' + $PowerShellExe + '" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $BridgeScript + '" "%1"'
Set-Item -Path "$ProtocolRoot\shell\open\command" -Value $Command

$Shell = New-Object -ComObject WScript.Shell

$ConfigureShortcut = $Shell.CreateShortcut((Join-Path $StartMenu 'إعداد المجلدات.lnk'))
$ConfigureShortcut.TargetPath = $PowerShellExe
$ConfigureShortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $InstallRoot 'Configure-DocumentArchiveFileBridge.ps1') + '"'
$ConfigureShortcut.WorkingDirectory = $InstallRoot
$ConfigureShortcut.Save()

$UninstallShortcut = $Shell.CreateShortcut((Join-Path $StartMenu 'إلغاء التثبيت.lnk'))
$UninstallShortcut.TargetPath = $PowerShellExe
$UninstallShortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $InstallRoot 'uninstall.ps1') + '"'
$UninstallShortcut.WorkingDirectory = $InstallRoot
$UninstallShortcut.Save()

if (-not $SkipConfiguration) {
    & $PowerShellExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $InstallRoot 'Configure-DocumentArchiveFileBridge.ps1')
}

Write-Host ''
Write-Host 'DocumentArchive File Bridge V94.2 installed successfully.' -ForegroundColor Green
Write-Host "Install folder: $InstallRoot"
Write-Host 'Protocol: documentarchive://'
Write-Host ''
Write-Host 'Close and reopen the browser before the first test.' -ForegroundColor Yellow
