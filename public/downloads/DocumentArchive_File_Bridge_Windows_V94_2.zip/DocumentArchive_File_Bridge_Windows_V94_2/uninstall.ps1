﻿$ErrorActionPreference = 'Stop'

$InstallRoot = Join-Path $env:LOCALAPPDATA 'DocumentArchiveFileBridge'
$StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\DocumentArchive File Bridge'
$ProtocolRoot = 'HKCU:\Software\Classes\documentarchive'

if (Test-Path -LiteralPath $ProtocolRoot) {
    Remove-Item -LiteralPath $ProtocolRoot -Recurse -Force
}

if (Test-Path -LiteralPath $StartMenu) {
    Remove-Item -LiteralPath $StartMenu -Recurse -Force
}

Write-Host 'DocumentArchive File Bridge protocol and shortcuts were removed.' -ForegroundColor Green
Write-Host 'The local configuration folder will now be deleted.'

$escaped = $InstallRoot.Replace('"', '""')
Start-Process -FilePath "$env:SystemRoot\System32\cmd.exe" -WindowStyle Hidden -ArgumentList @(
    '/c',
    "timeout /t 2 /nobreak >nul & rmdir /s /q \"$escaped\""
)
